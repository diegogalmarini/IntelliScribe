
import React, { useState, useRef, useEffect } from 'react';
import { UserProfile } from '../types';
import { useLanguage } from '../contexts/LanguageContext';
import { LanguageSelector } from '../components/LanguageSelector';
import { ThemeToggle } from '../components/ThemeToggle';

type SettingsTab = 'profile' | 'security' | 'notifications' | 'subscription';

interface SettingsProps {
    user: UserProfile;
    onUpdateUser: (updatedUser: Partial<UserProfile>) => void;
    onLogout: () => void;
    initialTab?: SettingsTab; // Add initialTab prop
}

export const Settings: React.FC<SettingsProps> = ({ user, onUpdateUser, onLogout, initialTab = 'profile' }) => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<SettingsTab>(initialTab);

  // Update tab if initialTab prop changes
  useEffect(() => {
    setActiveTab(initialTab);
  }, [initialTab]);

  // Local state form for Profile
  const [firstName, setFirstName] = useState(user.firstName);
  const [lastName, setLastName] = useState(user.lastName);
  const [email, setEmail] = useState(user.email);
  const [phone, setPhone] = useState(user.phone || '');
  const [phoneVerified, setPhoneVerified] = useState(user.phoneVerified || false);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(user.avatarUrl);
  
  // Notification State
  const [notifyNewRecording, setNotifyNewRecording] = useState(true);
  const [notifyWeeklyDigest, setNotifyWeeklyDigest] = useState(true);
  const [notifyMarketing, setNotifyMarketing] = useState(false);
  const [notifyBrowserPush, setNotifyBrowserPush] = useState(true);

  // Phone Verification Logic
  const [isVerifyingPhone, setIsVerifyingPhone] = useState(false);
  const [verificationCode, setVerificationCode] = useState('');
  
  // Feedback state
  const [feedback, setFeedback] = useState<{message: string, type: 'success' | 'error'} | null>(null);
  
  // Ref for the hidden file input
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Sync local state if user prop changes (e.g. initial load or external update)
  useEffect(() => {
      setFirstName(user.firstName);
      setLastName(user.lastName);
      setEmail(user.email);
      setPhone(user.phone || '');
      setPhoneVerified(user.phoneVerified || false);
      setAvatarUrl(user.avatarUrl);
  }, [user]);

  const handleAvatarClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleStartVerification = () => {
      if(!phone.trim()) {
          setFeedback({ message: "Enter a phone number first.", type: 'error' });
          setTimeout(() => setFeedback(null), 3000);
          return;
      }
      setIsVerifyingPhone(true);
      setFeedback({ message: t('verificationCodeSent'), type: 'success' });
      setTimeout(() => setFeedback(null), 3000);
  };

  const handleVerifyCode = () => {
      if(verificationCode === '1234') { // Mock check
          setPhoneVerified(true);
          setIsVerifyingPhone(false);
          setVerificationCode('');
          setFeedback({ message: "Number verified successfully!", type: 'success' });
      } else {
          setFeedback({ message: "Invalid code. Try 1234.", type: 'error' });
      }
      setTimeout(() => setFeedback(null), 3000);
  };

  const handleSave = () => {
      // Validate inputs
      if(!firstName.trim() || !lastName.trim() || !email.trim()) {
          setFeedback({ message: "Please fill in all required fields.", type: 'error' });
          setTimeout(() => setFeedback(null), 3000);
          return;
      }

      // Update global state
      onUpdateUser({
          firstName,
          lastName,
          email,
          phone,
          phoneVerified,
          avatarUrl
      });

      setFeedback({ message: "Changes saved successfully.", type: 'success' });
      setTimeout(() => setFeedback(null), 3000);
  };

  const handleCancel = () => {
      // Reset to props
      setFirstName(user.firstName);
      setLastName(user.lastName);
      setEmail(user.email);
      setPhone(user.phone || '');
      setPhoneVerified(user.phoneVerified || false);
      setAvatarUrl(user.avatarUrl);
      setIsVerifyingPhone(false);
      
      setFeedback({ message: "Changes discarded.", type: 'success' }); 
      setTimeout(() => setFeedback(null), 3000);
  };

  // --- Pricing Logic ---
  const [billingInterval, setBillingInterval] = useState<'monthly' | 'annual'>('annual');
  const [currency, setCurrency] = useState<'USD' | 'EUR'>('USD');
  
  // Simulated Exchange Rate (In a real app, fetch this from an API)
  const EXCHANGE_RATE_USD_TO_EUR = 0.92;

  const formatPrice = (priceInUSD: number): string => {
      // Specific handling for Free plan to return text instead of currency
      if (priceInUSD === 0) return t('freePrice');
      
      if (currency === 'USD') {
          return `$${priceInUSD}`;
      } else {
          // Calculate EUR and format
          const eur = priceInUSD * EXCHANGE_RATE_USD_TO_EUR;
          // Use nice formatting for whole numbers or decimals
          return `€${eur.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
      }
  };

  const renderContent = () => {
      switch (activeTab) {
          case 'profile':
              return (
                <div className="flex flex-col gap-8 animate-in fade-in duration-300">
                    <section>
                        <h4 className="text-slate-900 dark:text-white text-lg font-bold mb-6">{t('personalInfo')}</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="flex flex-col gap-2">
                                <label className="text-slate-700 dark:text-white text-sm font-medium">{t('firstName')}</label>
                                <input 
                                    className="bg-white dark:bg-surface-dark text-slate-900 dark:text-white border border-slate-300 dark:border-border-dark rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-brand-blue focus:border-transparent outline-none transition-all" 
                                    value={firstName} 
                                    onChange={(e) => setFirstName(e.target.value)}
                                />
                            </div>
                            <div className="flex flex-col gap-2">
                                <label className="text-slate-700 dark:text-white text-sm font-medium">{t('lastName')}</label>
                                <input 
                                    className="bg-white dark:bg-surface-dark text-slate-900 dark:text-white border border-slate-300 dark:border-border-dark rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-brand-blue focus:border-transparent outline-none transition-all" 
                                    value={lastName}
                                    onChange={(e) => setLastName(e.target.value)}
                                />
                            </div>
                            <div className="flex flex-col gap-2 md:col-span-2">
                                <label className="text-slate-700 dark:text-white text-sm font-medium">{t('emailLabel')}</label>
                                <input 
                                    className="bg-white dark:bg-surface-dark text-slate-900 dark:text-white border border-slate-300 dark:border-border-dark rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-brand-blue focus:border-transparent outline-none transition-all" 
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                />
                            </div>
                            
                            {/* Phone Verification Section */}
                            <div className="flex flex-col gap-2 md:col-span-2 border-t border-slate-200 dark:border-border-dark pt-6 mt-2">
                                <div className="flex items-center justify-between mb-2">
                                    <label className="text-slate-700 dark:text-white text-sm font-medium">{t('phoneLabel')}</label>
                                    <span className={`text-xs px-2 py-0.5 rounded-full font-bold uppercase ${phoneVerified ? 'bg-brand-green/10 text-brand-green' : 'bg-yellow-500/10 text-yellow-500'}`}>
                                        {phoneVerified ? t('verified') : t('unverified')}
                                    </span>
                                </div>
                                
                                <div className="flex gap-2">
                                    <input 
                                        className="flex-1 bg-white dark:bg-surface-dark text-slate-900 dark:text-white border border-slate-300 dark:border-border-dark rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-brand-blue focus:border-transparent outline-none transition-all disabled:opacity-50" 
                                        value={phone}
                                        onChange={(e) => {
                                            setPhone(e.target.value);
                                            setPhoneVerified(false); // Reset verification on change
                                        }}
                                        placeholder="+1 555 123 4567"
                                        disabled={isVerifyingPhone}
                                    />
                                    {!phoneVerified && !isVerifyingPhone && (
                                        <button 
                                            onClick={handleStartVerification}
                                            className="px-4 py-2 bg-brand-blue/10 hover:bg-brand-blue/20 text-brand-blue border border-brand-blue/30 rounded-lg text-sm font-bold transition-colors">
                                            {t('verifyNow')}
                                        </button>
                                    )}
                                </div>
                                
                                {isVerifyingPhone && (
                                    <div className="mt-2 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark p-4 rounded-lg animate-in slide-in-from-top-2">
                                        <p className="text-sm text-slate-600 dark:text-slate-300 mb-2">{t('enterCode')}</p>
                                        <div className="flex gap-2">
                                            <input 
                                                className="w-32 bg-slate-50 dark:bg-[#111722] text-slate-900 dark:text-white border border-slate-300 dark:border-border-dark rounded-lg px-3 py-2 text-center tracking-widest font-mono"
                                                placeholder="0000"
                                                value={verificationCode}
                                                onChange={(e) => setVerificationCode(e.target.value)}
                                            />
                                            <button 
                                                onClick={handleVerifyCode}
                                                className="px-4 py-2 bg-brand-green hover:bg-brand-green/90 text-slate-900 font-bold rounded-lg text-sm transition-colors">
                                                {t('verifyBtn')}
                                            </button>
                                            <button 
                                                onClick={() => setIsVerifyingPhone(false)}
                                                className="px-4 py-2 text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-white text-sm font-medium">
                                                {t('cancel')}
                                            </button>
                                        </div>
                                        <p className="text-xs text-slate-500 mt-2">Hint: Use 1234</p>
                                    </div>
                                )}
                                <p className="text-xs text-slate-500 mt-1">{t('verifyDesc')}</p>
                            </div>
                        </div>
                    </section>
                </div>
              );
          case 'subscription':
              return (
                  <div className="flex flex-col gap-8 animate-in fade-in duration-300">
                      {/* Current Plan Status - Using Gradient Background */}
                      <div className="bg-gradient-brand p-[1px] rounded-xl shadow-lg">
                        <div className="bg-white dark:bg-[#111722] p-6 rounded-[11px] flex flex-col md:flex-row items-center justify-between gap-4 h-full relative overflow-hidden">
                            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-brand opacity-20"></div>
                            <div className="z-10">
                                <p className="text-transparent bg-clip-text bg-gradient-brand font-bold text-sm mb-1">{t('currentPlan')}</p>
                                <h3 className="text-3xl font-black text-slate-900 dark:text-white capitalize tracking-tight">{user.subscription.planId === 'business_plus' ? 'Business +' : user.subscription.planId === 'business' ? 'Business' : user.subscription.planId === 'pro' ? 'Pro' : 'Free'}</h3>
                                <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">
                                    {user.subscription.planId === 'free' 
                                        ? `${user.subscription.minutesUsed} / ${user.subscription.minutesLimit} minutes used this month.`
                                        : 'Unlimited access active.'}
                                </p>
                            </div>
                            <div className="flex items-center gap-4 z-10">
                                    <div className="text-right">
                                        <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold border ${user.subscription.status === 'active' ? 'bg-brand-green/10 text-brand-green border-brand-green/20' : 'bg-red-500/10 text-red-500 border-red-500/20'}`}>
                                            {user.subscription.status.toUpperCase()}
                                        </span>
                                    </div>
                            </div>
                        </div>
                      </div>

                      {/* Controls Row */}
                      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                          {/* Currency Toggle */}
                          <div className="flex items-center gap-2 bg-white dark:bg-surface-dark p-1 rounded-lg border border-slate-200 dark:border-border-dark">
                              <button 
                                  onClick={() => setCurrency('USD')}
                                  className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${currency === 'USD' ? 'bg-brand-blue text-white' : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'}`}>
                                  USD ($)
                              </button>
                              <button 
                                  onClick={() => setCurrency('EUR')}
                                  className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${currency === 'EUR' ? 'bg-brand-blue text-white' : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white'}`}>
                                  EUR (€)
                              </button>
                          </div>

                          {/* Interval Toggle */}
                          <div className="bg-white dark:bg-surface-dark p-1 rounded-xl border border-slate-200 dark:border-border-dark inline-flex">
                              <button 
                                  onClick={() => setBillingInterval('monthly')}
                                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${billingInterval === 'monthly' ? 'bg-slate-200 dark:bg-slate-700 text-slate-900 dark:text-white shadow' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'}`}>
                                  {t('monthly')}
                              </button>
                              <button 
                                  onClick={() => setBillingInterval('annual')}
                                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${billingInterval === 'annual' ? 'bg-slate-200 dark:bg-slate-700 text-slate-900 dark:text-white shadow' : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'}`}>
                                  {t('annual')}
                                  <span className="text-[10px] bg-brand-green text-slate-900 px-1.5 rounded font-bold">{t('save20')}</span>
                              </button>
                          </div>
                      </div>

                      {/* Pricing Cards Grid (4 Columns) */}
                      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6 pt-6">
                          
                          {/* 1. FREE PLAN - GREY */}
                          <div className={`rounded-3xl border flex flex-col transition-all duration-300 bg-white dark:bg-surface-dark overflow-hidden hover:shadow-xl ${user.subscription.planId === 'free' ? 'border-brand-grey ring-1 ring-brand-grey shadow-lg' : 'border-slate-200 dark:border-border-dark hover:border-brand-grey/50'}`}>
                              <div className="h-2 w-full bg-brand-grey"></div>
                              <div className="p-6 flex flex-col h-full">
                                  <div className="flex justify-between items-start">
                                      <div>
                                          <h4 className="text-lg font-bold text-brand-grey dark:text-slate-200">{t('freeTitle')}</h4>
                                          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 min-h-[32px]">{t('freeDesc')}</p>
                                      </div>
                                      {user.subscription.planId === 'free' && <span className="bg-brand-grey text-white text-[10px] px-2 py-0.5 rounded font-bold uppercase">Active</span>}
                                  </div>
                                  
                                  <div className="mt-4 mb-6">
                                    <p className="text-3xl font-black text-slate-900 dark:text-white">{formatPrice(0)}</p>
                                    <p className="text-slate-400 text-[10px] mt-1 uppercase tracking-wide font-medium">{t('currency')}</p>
                                  </div>

                                  <div className="flex-1">
                                    <ul className="flex flex-col gap-3 mb-8">
                                        {[t('freeF1'), t('freeF2'), t('freeF3')].map((feat, i) => (
                                            <li key={i} className="flex items-start gap-3 text-slate-600 dark:text-slate-300 text-xs">
                                                <span className="material-symbols-outlined text-brand-grey dark:text-slate-400 text-sm font-bold">check</span>
                                                <span className="leading-tight">{feat}</span>
                                            </li>
                                        ))}
                                    </ul>
                                  </div>
                                  <button disabled={user.subscription.planId === 'free'} className="w-full py-3 rounded-xl border border-brand-grey text-brand-grey dark:text-slate-300 font-bold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-50 dark:hover:bg-white/5 transition-colors text-xs uppercase tracking-wider">
                                      {user.subscription.planId === 'free' ? 'Current Plan' : 'Downgrade'}
                                  </button>
                              </div>
                          </div>

                          {/* 2. PRO PLAN - VIOLET (#8F53ED) */}
                          <div className={`rounded-3xl border flex flex-col transition-all duration-300 bg-white dark:bg-surface-dark overflow-hidden hover:shadow-xl relative transform hover:-translate-y-1 ${user.subscription.planId === 'pro' ? 'border-brand-violet ring-1 ring-brand-violet shadow-lg' : 'border-slate-200 dark:border-border-dark hover:border-brand-violet/50'}`}>
                                <div className="h-2 w-full bg-brand-violet"></div>
                                <div className="p-6 flex flex-col h-full">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <div className="flex items-center gap-2">
                                                <h4 className="text-lg font-bold text-slate-900 dark:text-white">{t('proTitle')}</h4>
                                                <span className="text-[10px] font-bold text-white bg-brand-violet px-2 py-0.5 rounded-full">{t('proBadge')}</span>
                                            </div>
                                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 min-h-[32px]">{t('proDesc')}</p>
                                        </div>
                                    </div>
                                    
                                    <div className="mt-4 mb-6">
                                        <p className="text-3xl font-black text-brand-violet dark:text-white">
                                            {formatPrice(billingInterval === 'annual' ? 9 : 12)}
                                            <span className="text-sm font-normal text-slate-500 dark:text-slate-400">/mo</span>
                                        </p>
                                        <p className="text-slate-500 text-[10px] mt-1">{billingInterval === 'annual' ? 'Billed annually' : 'Billed monthly'}</p>
                                    </div>
                                    
                                    <div className="flex-1">
                                        <ul className="flex flex-col gap-3 mb-8">
                                            {[t('proF1'), t('proF2'), t('proF3')].map((feat, i) => (
                                                <li key={i} className="flex items-start gap-3 text-slate-700 dark:text-white text-xs">
                                                    <span className="material-symbols-outlined text-brand-violet text-sm font-bold">check</span>
                                                    <span className="leading-tight">{feat}</span>
                                                </li>
                                            ))}
                                        </ul>
                                    </div>
                                    <button className="w-full py-3 rounded-xl bg-brand-violet hover:bg-[#7a42d1] text-white font-bold transition-colors text-xs uppercase tracking-wider shadow-md shadow-brand-violet/20">
                                        {t('subscribe')}
                                    </button>
                                </div>
                          </div>

                          {/* 3. BUSINESS - BLUE (#2CA3FF) */}
                          <div className={`rounded-3xl border flex flex-col transition-all duration-300 bg-white dark:bg-surface-dark overflow-hidden hover:shadow-xl relative transform hover:-translate-y-1 ${user.subscription.planId === 'business' ? 'border-brand-blue ring-1 ring-brand-blue shadow-lg' : 'border-slate-200 dark:border-border-dark hover:border-brand-blue/50'}`}>
                                <div className="h-2 w-full bg-brand-blue"></div>
                                <div className="p-6 flex flex-col h-full">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <div className="flex items-center gap-2">
                                                <h4 className="text-lg font-bold text-slate-900 dark:text-white">{t('bizTitle')}</h4>
                                                <span className="text-[10px] font-bold text-white bg-brand-blue px-2 py-0.5 rounded-full">{t('bizBadge')}</span>
                                            </div>
                                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 min-h-[32px]">{t('bizDesc')}</p>
                                        </div>
                                    </div>
                                  
                                  <div className="mt-4 mb-6">
                                      <p className="text-3xl font-black text-brand-blue dark:text-white">
                                          {formatPrice(billingInterval === 'annual' ? 15 : 19)}
                                          <span className="text-sm font-normal text-slate-500 dark:text-slate-400">/mo</span>
                                      </p>
                                      <p className="text-slate-500 text-[10px] mt-1">{billingInterval === 'annual' ? 'Billed annually' : 'Billed monthly'}</p>
                                  </div>
                                  
                                  <div className="flex-1">
                                    <ul className="flex flex-col gap-3 mb-8">
                                        {[t('bizF1'), t('bizF2'), t('bizF3'), t('bizF4')].map((feat, i) => (
                                            <li key={i} className="flex items-start gap-3 text-slate-700 dark:text-white text-xs">
                                                <span className="material-symbols-outlined text-brand-blue text-sm font-bold">verified</span>
                                                <span className="leading-tight font-medium">{feat}</span>
                                            </li>
                                        ))}
                                    </ul>
                                  </div>
                                  <button className="w-full py-3 rounded-xl bg-brand-blue hover:bg-[#208ade] text-white font-bold transition-all shadow-md shadow-brand-blue/25 text-xs uppercase tracking-wider">
                                      {t('subscribe')}
                                  </button>
                                </div>
                          </div>

                          {/* 4. BUSINESS + CALLS - GREEN (#39F672) */}
                          <div className={`rounded-3xl border flex flex-col transition-all duration-300 bg-white dark:bg-surface-dark overflow-hidden hover:shadow-xl relative transform hover:-translate-y-1 ${user.subscription.planId === 'business_plus' ? 'border-brand-green ring-1 ring-brand-green shadow-lg' : 'border-slate-200 dark:border-border-dark hover:border-brand-green/50'}`}>
                                <div className="h-2 w-full bg-brand-green"></div>
                                <div className="p-6 flex flex-col h-full bg-gradient-to-b from-brand-green/5 to-transparent">
                                    <div className="flex justify-between items-start">
                                        <div>
                                            <div className="flex items-center gap-2">
                                                <h4 className="text-lg font-black text-slate-900 dark:text-white">{t('bizPlusTitle')}</h4>
                                                <span className="text-[10px] font-bold text-slate-900 bg-brand-green px-2 py-0.5 rounded-full">{t('bizPlusBadge')}</span>
                                            </div>
                                            <p className="text-xs text-slate-500 dark:text-slate-300 mt-1 min-h-[32px]">{t('bizPlusDesc')}</p>
                                        </div>
                                    </div>
                                  
                                  <div className="mt-4 mb-6">
                                      <p className="text-3xl font-black text-brand-blue dark:text-white">
                                          {formatPrice(billingInterval === 'annual' ? 25 : 35)}
                                          <span className="text-sm font-normal text-slate-500 dark:text-slate-400">/mo</span>
                                      </p>
                                      <p className="text-slate-500 text-[10px] mt-1">{billingInterval === 'annual' ? 'Billed annually' : 'Billed monthly'}</p>
                                  </div>
                                  
                                  <div className="flex-1">
                                    <ul className="flex flex-col gap-3 mb-8">
                                        {[t('bizPlusF1'), t('bizPlusF2'), t('bizPlusF3')].map((feat, i) => (
                                            <li key={i} className="flex items-start gap-3 text-slate-700 dark:text-white text-xs">
                                                <span className="material-symbols-outlined text-brand-green text-sm font-bold">stars</span>
                                                <span className="leading-tight font-bold">{feat}</span>
                                            </li>
                                        ))}
                                    </ul>
                                  </div>
                                  <button className="w-full py-3 rounded-xl bg-brand-green hover:bg-brand-green/90 text-slate-900 font-bold transition-all shadow-md shadow-brand-green/25 text-xs uppercase tracking-wider transform group-hover:scale-105">
                                      {t('subscribe')}
                                  </button>
                                </div>
                          </div>

                      </div>
                  </div>
              );
          case 'notifications':
              return (
                <div className="flex flex-col gap-8 animate-in fade-in duration-300">
                    <section>
                        <h4 className="text-slate-900 dark:text-white text-lg font-bold mb-6">{t('notifyEmailGroup')}</h4>
                        <div className="flex flex-col gap-4">
                            {/* Toggle 1 */}
                            <div className="flex items-center justify-between p-4 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl">
                                <div>
                                    <h5 className="text-sm font-bold text-slate-900 dark:text-white">{t('notifyNewRecording')}</h5>
                                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{t('notifyNewRecordingDesc')}</p>
                                </div>
                                <div className="form-control">
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" className="sr-only peer" checked={notifyNewRecording} onChange={() => setNotifyNewRecording(!notifyNewRecording)} />
                                        <div className="w-11 h-6 bg-slate-200 dark:bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-blue"></div>
                                    </label>
                                </div>
                            </div>
                            
                            {/* Toggle 2 */}
                            <div className="flex items-center justify-between p-4 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl">
                                <div>
                                    <h5 className="text-sm font-bold text-slate-900 dark:text-white">{t('notifyWeeklyDigest')}</h5>
                                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{t('notifyWeeklyDigestDesc')}</p>
                                </div>
                                <div className="form-control">
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" className="sr-only peer" checked={notifyWeeklyDigest} onChange={() => setNotifyWeeklyDigest(!notifyWeeklyDigest)} />
                                        <div className="w-11 h-6 bg-slate-200 dark:bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-blue"></div>
                                    </label>
                                </div>
                            </div>

                             {/* Toggle 3 */}
                             <div className="flex items-center justify-between p-4 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl">
                                <div>
                                    <h5 className="text-sm font-bold text-slate-900 dark:text-white">{t('notifyMarketing')}</h5>
                                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{t('notifyMarketingDesc')}</p>
                                </div>
                                <div className="form-control">
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" className="sr-only peer" checked={notifyMarketing} onChange={() => setNotifyMarketing(!notifyMarketing)} />
                                        <div className="w-11 h-6 bg-slate-200 dark:bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-blue"></div>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section>
                        <h4 className="text-slate-900 dark:text-white text-lg font-bold mb-6">{t('notifyBrowserGroup')}</h4>
                        <div className="flex flex-col gap-4">
                            <div className="flex items-center justify-between p-4 bg-white dark:bg-surface-dark border border-slate-200 dark:border-border-dark rounded-xl">
                                <div>
                                    <h5 className="text-sm font-bold text-slate-900 dark:text-white">{t('notifyBrowserPush')}</h5>
                                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{t('notifyBrowserPushDesc')}</p>
                                </div>
                                <div className="form-control">
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" className="sr-only peer" checked={notifyBrowserPush} onChange={() => setNotifyBrowserPush(!notifyBrowserPush)} />
                                        <div className="w-11 h-6 bg-slate-200 dark:bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-brand-blue"></div>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
              );
          case 'security':
              return (
                <div className="flex flex-col gap-8 animate-in fade-in duration-300">
                    <section>
                        <h4 className="text-slate-900 dark:text-white text-lg font-bold mb-6">Password & Authentication</h4>
                        <div className="flex flex-col gap-6 max-w-xl">
                            <div className="flex flex-col gap-2">
                                <label className="text-slate-700 dark:text-white text-sm font-medium">Current Password</label>
                                <input type="password" className="bg-white dark:bg-surface-dark text-slate-900 dark:text-white border border-slate-300 dark:border-border-dark rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-brand-blue focus:border-transparent outline-none" placeholder="••••••••" />
                            </div>
                            <div className="flex flex-col gap-2">
                                <label className="text-slate-700 dark:text-white text-sm font-medium">New Password</label>
                                <input type="password" className="bg-white dark:bg-surface-dark text-slate-900 dark:text-white border border-slate-300 dark:border-border-dark rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-brand-blue focus:border-transparent outline-none" placeholder="••••••••" />
                            </div>
                            <div className="flex flex-col gap-2">
                                <label className="text-slate-700 dark:text-white text-sm font-medium">Confirm New Password</label>
                                <input type="password" className="bg-white dark:bg-surface-dark text-slate-900 dark:text-white border border-slate-300 dark:border-border-dark rounded-lg px-4 py-2.5 focus:ring-2 focus:ring-brand-blue focus:border-transparent outline-none" placeholder="••••••••" />
                            </div>
                            <button type="button" className="self-start px-4 py-2 bg-slate-100 dark:bg-surface-dark hover:bg-slate-200 dark:hover:bg-[#2f3e5c] border border-slate-300 dark:border-border-dark rounded-lg text-slate-700 dark:text-white text-sm font-medium transition-colors">
                                Update Password
                            </button>
                        </div>
                    </section>
                </div>
              );
      }
      return null;
  };

  return (
    <div className="flex-1 flex flex-col h-screen bg-background-light dark:bg-background-dark overflow-hidden transition-colors duration-200">
        <header className="flex items-center justify-between whitespace-nowrap border-b border-solid border-slate-200 dark:border-border-dark bg-white dark:bg-[#111722] px-4 md:px-10 py-3 transition-colors duration-200">
            <h2 className="text-slate-900 dark:text-white text-lg font-bold">{t('settings')}</h2>
            
            <div className="flex items-center gap-4">
                <ThemeToggle />
                <LanguageSelector />
                <button 
                    type="button"
                    onClick={onLogout}
                    className="flex min-w-[84px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-slate-100 dark:bg-surface-dark hover:bg-slate-200 dark:hover:bg-[#2f3e5c] text-slate-700 dark:text-white text-sm font-bold leading-normal transition-colors border border-slate-300 dark:border-border-dark">
                    <span className="truncate">{t('logout')}</span>
                </button>
            </div>
            
            {/* Feedback Toast */}
            {feedback && (
                <div className={`fixed top-4 left-1/2 -translate-x-1/2 px-4 py-2 rounded-lg shadow-xl text-sm font-medium animate-in fade-in zoom-in slide-in-from-top-4 flex items-center gap-2 z-50 ${feedback.type === 'success' ? 'bg-brand-green/10 text-brand-green border border-brand-green/20' : 'bg-red-500/10 text-red-500 border border-red-500/20'}`}>
                    <span className="material-symbols-outlined text-lg">{feedback.type === 'success' ? 'check_circle' : 'error'}</span>
                    {feedback.message}
                </div>
            )}
        </header>

        <div className="flex-1 overflow-y-auto p-4 md:p-10">
            <div className="max-w-5xl mx-auto flex flex-col gap-8">
                {/* Page Heading */}
                <div className="flex flex-col gap-2">
                    <h1 className="text-slate-900 dark:text-white text-3xl font-black">{t('accountSettings')}</h1>
                    <p className="text-slate-500 dark:text-text-secondary">{t('managePersonal')}</p>
                </div>

                <div className="flex flex-col lg:flex-row gap-8">
                    {/* Sidebar Nav */}
                    <aside className="w-full lg:w-64 flex-shrink-0">
                        <div className="flex flex-col gap-1">
                            <button 
                                type="button"
                                onClick={() => setActiveTab('profile')}
                                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg border transition-colors font-medium text-sm w-full text-left ${activeTab === 'profile' ? 'bg-brand-blue/10 text-brand-blue border-brand-blue/20 font-bold' : 'text-slate-500 dark:text-text-secondary hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-white/5 border-transparent'}`}
                            >
                                <span className={`material-symbols-outlined text-[20px] ${activeTab === 'profile' ? 'material-symbols-filled' : ''}`}>person</span>
                                {t('myProfile')}
                            </button>
                            <button 
                                type="button"
                                onClick={() => setActiveTab('subscription')}
                                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg border transition-colors font-medium text-sm w-full text-left ${activeTab === 'subscription' ? 'bg-brand-blue/10 text-brand-blue border-brand-blue/20 font-bold' : 'text-slate-500 dark:text-text-secondary hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-white/5 border-transparent'}`}
                            >
                                <span className={`material-symbols-outlined text-[20px] ${activeTab === 'subscription' ? 'material-symbols-filled' : ''}`}>credit_card</span>
                                {t('subscription')}
                            </button>
                            <button 
                                type="button"
                                onClick={() => setActiveTab('security')}
                                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg border transition-colors font-medium text-sm w-full text-left ${activeTab === 'security' ? 'bg-brand-blue/10 text-brand-blue border-brand-blue/20 font-bold' : 'text-slate-500 dark:text-text-secondary hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-white/5 border-transparent'}`}
                            >
                                <span className={`material-symbols-outlined text-[20px] ${activeTab === 'security' ? 'material-symbols-filled' : ''}`}>shield</span>
                                {t('security')}
                            </button>
                            <button 
                                type="button"
                                onClick={() => setActiveTab('notifications')}
                                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg border transition-colors font-medium text-sm w-full text-left ${activeTab === 'notifications' ? 'bg-brand-blue/10 text-brand-blue border-brand-blue/20 font-bold' : 'text-slate-500 dark:text-text-secondary hover:text-slate-900 dark:hover:text-white hover:bg-slate-200 dark:hover:bg-white/5 border-transparent'}`}
                            >
                                <span className={`material-symbols-outlined text-[20px] ${activeTab === 'notifications' ? 'material-symbols-filled' : ''}`}>notifications</span>
                                {t('notifications')}
                            </button>
                        </div>
                    </aside>

                    {/* Main Content */}
                    <main className="flex-1 bg-white dark:bg-[#161d2a] rounded-xl border border-slate-200 dark:border-border-dark overflow-hidden shadow-sm">
                        <div className="p-8 border-b border-slate-200 dark:border-border-dark">
                            <div className="flex items-center gap-6">
                                {/* Hidden Input */}
                                <input 
                                    type="file" 
                                    ref={fileInputRef} 
                                    onChange={handleFileChange} 
                                    accept="image/*" 
                                    className="hidden" 
                                />
                                
                                {/* Avatar Click Area */}
                                <div 
                                    className="relative group cursor-pointer shrink-0" 
                                    onClick={handleAvatarClick}
                                    title="Click to change photo"
                                >
                                    <div className="size-24 rounded-full bg-gradient-brand flex items-center justify-center text-white text-2xl font-bold border-4 border-white dark:border-surface-dark shadow-xl overflow-hidden relative">
                                        {avatarUrl ? (
                                            <img src={avatarUrl} alt="Profile" className="w-full h-full object-cover" />
                                        ) : (
                                            <span>{firstName[0]}{lastName[0]}</span>
                                        )}
                                    </div>
                                    <div className="absolute inset-0 bg-black/40 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                        <span className="material-symbols-outlined text-white">photo_camera</span>
                                    </div>
                                </div>
                                
                                <div>
                                    <h3 className="text-slate-900 dark:text-white text-2xl font-bold">{firstName} {lastName}</h3>
                                    <p className="text-slate-500 dark:text-text-secondary">{user.role}</p>
                                    <button 
                                        type="button"
                                        onClick={handleAvatarClick}
                                        className="mt-2 text-brand-blue text-sm font-medium hover:underline md:hidden">
                                        {t('changePhoto')}
                                    </button>
                                </div>
                            </div>
                        </div>

                        <div className="p-8">
                           {renderContent()}
                           
                           {/* Footer Actions (Only for profile for now, or could be shared) */}
                           {(activeTab === 'profile' || activeTab === 'notifications') && (
                                <div className="flex justify-end gap-4 pt-8 mt-8 border-t border-slate-200 dark:border-border-dark">
                                        <button 
                                            type="button"
                                            onClick={handleCancel}
                                            className="px-6 py-2.5 rounded-lg text-sm font-bold text-slate-500 dark:text-text-secondary hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-surface-dark transition-colors">
                                            {t('cancel')}
                                        </button>
                                        <button 
                                            type="button"
                                            onClick={handleSave}
                                            className="px-6 py-2.5 rounded-lg bg-brand-blue hover:bg-brand-blue/90 text-white text-sm font-bold shadow-lg shadow-brand-blue/20 transition-all active:scale-95">
                                            {t('saveChanges')}
                                        </button>
                                </div>
                           )}
                        </div>
                    </main>
                </div>
            </div>
        </div>
    </div>
  );
};
