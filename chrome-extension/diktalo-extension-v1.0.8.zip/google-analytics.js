async function r(n,e={}){{console.warn("GA4 Not Configured: Missing API Secret");return}}export{r as f};
